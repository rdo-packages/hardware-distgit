========
Usage
========

To use hardware in a project::

    import hardware
