============
Installation
============

At the command line::

    $ pip install hardware

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv hardware
    $ pip install hardware
