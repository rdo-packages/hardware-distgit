"""
Module to run benchmark tests for CPU, disks and memory.
"""
