If you would like to contribute to the development of the hardware
module, use Pull Requests from github:

   https://github.com/enovance/hardware

To report a bug, take a look if you bug has already been reported on:

https://github.com/enovance/hardware/issues

If your bug is new, it should be filed on GitHub:

   https://github.com/enovance/hardware/issues/new
